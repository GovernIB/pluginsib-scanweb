#!/bin/sh
var=50
while :
do
PROCESS_NUM=`find /etc/rcS.d -name "*""$var""*"| wc -l` 
if [ $PROCESS_NUM -eq 0 ]; then
	ln -s /etc/init.d/DynamsoftServiced "/etc/rcS.d/S""$var""DynamsoftServiced"
	break
else
	var=`expr $var + 1`
fi
done

/opt/dynamsoft/DynamsoftService/DynamsoftServiceMgr&

